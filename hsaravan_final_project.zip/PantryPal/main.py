"""
Harini Saravanan
Class: CS 521 - Fall 2024
Date: 12/11/2024
Final Project
Description of Project:
The Problem:

1) People often struggle to decide what to cook with the ingredients they already have.
2) Searching for recipes online can be time-consuming and overwhelming.
The Solution:

1) Pantry Pal provides an easy way to discover recipes using ingredients in your pantry.
2) Offers both local recipe suggestions and online options to save time and effort.
"""

from pantry_class import Pantry

def main():
    print("Welcome to Pantry Pal!")
    
    # Get user input for ingredients
    user_ingredients = input("Enter the ingredients in your pantry (comma-separated): ").split(',')
    user_ingredients = [ingredient.strip().lower() for ingredient in user_ingredients]
    
    # Save ingredients to a file
    try:
        with open('ingredients.txt', 'w') as f:
            f.write(', '.join(user_ingredients))
    except IOError as e:
        print("Error writing to file:", e)
        return
    
    # Initialize the Pantry class
    pantry = Pantry(user_ingredients)
    
    # Find and display recipes from the internal recipe database
    print("\nFinding recipes from pantry ingredients...")
    try:
        recipes = pantry.find_recipes()
        if recipes:
            print("Recipes found:")
            for recipe in recipes:
                print(f"- {recipe}")
        else:
            print("No recipes found with the given ingredients.")
    except Exception as e:
        print("An error occurred while finding recipes:", e)

    # Optionally, search online for recipes
    search_online = input("\nDo you want to search for recipes online based on your ingredients? (yes/no): ").lower()
    if search_online == 'yes':
        search_query = ', '.join(user_ingredients)
        print(f"\nSearching for recipes online with ingredients: {search_query}")
        online_recipes = pantry.scrape_recipes(search_query)
        if online_recipes:
            print("Online recipes found:")
            for recipe in online_recipes:
                print(f"- {recipe}")
        else:
            print("No online recipes found.")

if __name__ == "__main__":
    main()
