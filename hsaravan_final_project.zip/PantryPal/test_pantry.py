import unittest
from pantry_class import Pantry
import requests

class TestPantry(unittest.TestCase):
    
    def setUp(self):
        """Setup test data for each test."""
        self.pantry = Pantry(["pasta", "tomato", "cheese", "egg", "milk", "lettuce"])
    
    def test_repr(self):
        """Test the __repr__ method."""
        self.assertEqual(repr(self.pantry), "Pantry(6 ingredients)")
    
    def test_find_recipes(self):
        """Test the find_recipes method."""
        # Test the list of recipes found based on the pantry ingredients
        recipes = self.pantry.find_recipes()
        expected_recipes = ["Pasta", "Omelette"]  # Add Salad and Sandwich
        self.assertEqual(recipes, expected_recipes)

    def test_add_ingredient(self):
        """Test the add_ingredient method."""
        self.pantry.add_ingredient("bread")
        # Check if the new ingredient has been added
        self.assertIn("bread", self.pantry._ingredients)
    
    def test_scrape_recipes_success(self):
        """Test the scrape_recipes method (successful API call)."""
        api_key = "37934da85d5145d69a560b95c60f7c1e"  # Replace with your actual API key
        search_query = "pasta, tomato"
        url = f"https://api.spoonacular.com/recipes/findByIngredients?ingredients={search_query.replace(' ', ',')}&apiKey={api_key}"
        
        # Send a real API request
        response = requests.get(url)
        
        # Check if the response status is OK (200)
        self.assertEqual(response.status_code, 200)
        
        # If the request is successful, check that the response contains recipes
        data = response.json()
        self.assertGreater(len(data), 0)  # Ensure that the response contains at least one recipe
        self.assertIn("title", data[0])  # Ensure that each recipe contains a 'title' key

    def test_scrape_recipes_failure(self):
        """Test the scrape_recipes method (failed API call)."""
        # Simulate a failed API response (e.g., by using an incorrect API key or network failure)
        api_key = "incorrect_api_key"  # Use an invalid API key
        search_query = "pasta, tomato"
        url = f"https://api.spoonacular.com/recipes/findByIngredients?ingredients={search_query.replace(' ', ',')}&apiKey={api_key}"
        
        # Send a real API request that should fail due to the incorrect API key
        response = requests.get(url)
        
        # Check that the response status is not OK (not 200)
        self.assertNotEqual(response.status_code, 200)
        self.assertIn("status", response.json())  # Ensure that error information is present

if __name__ == "__main__":
    unittest.main()
