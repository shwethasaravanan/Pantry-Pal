import requests

class Pantry:
    def __init__(self, ingredients):
        self._ingredients = set(ingredients)  # private attribute
        self.recipe_database = {  # public attribute with more recipes
            "Pasta": {"pasta", "tomato", "cheese"},
            "Omelette": {"egg", "milk", "cheese"},
            "Salad": {"lettuce", "tomato", "cucumber"},
            "Pizza": {"flour", "tomato", "cheese", "basil"},
            "Sandwich": {"bread", "cheese", "lettuce", "tomato"},
            "Pancakes": {"flour", "milk", "egg", "sugar"},
            "Soup": {"tomato", "carrot", "onion", "celery"},
            "Cake": {"flour", "sugar", "egg", "butter"}
        }

    def __repr__(self):
        return f"Pantry({len(self._ingredients)} ingredients)"
    
    def _is_recipe_possible(self, recipe_ingredients):
        """Private method to check if a recipe is possible"""
        return recipe_ingredients.issubset(self._ingredients)
    
    def find_recipes(self):
        """Public method to find possible recipes"""
        possible_recipes = []
        for recipe, ingredients in self.recipe_database.items():
            if self._is_recipe_possible(ingredients):
                possible_recipes.append(recipe)
        return possible_recipes
    
    def add_ingredient(self, ingredient):
        """Public method to add a new ingredient"""
        self._ingredients.add(ingredient)

    def __enter__(self):
        """Dunder method to handle resource management"""
        print("Pantry ready to use.")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Dunder method for cleanup"""
        print("Pantry cleanup complete.")
    
    def scrape_recipes(self, search_query):
        """Scrape recipe websites to find recipes based on user input"""
        try:
            api_key = "37934da85d5145d69a560b95c60f7c1e"  # Replace with API key
            url = f"https://api.spoonacular.com/recipes/findByIngredients?ingredients={search_query.replace(' ', ',')}&apiKey={api_key}"

            # Fetch recipe data
            response = requests.get(url)
            data = response.json()

            recipes = []
            for recipe in data:
                recipes.append(recipe['title'])

            return recipes if recipes else ["No recipes found."]
        except Exception as e:
            print(f"Error during API fetch: {e}")
            return ["Error fetching recipes."]
